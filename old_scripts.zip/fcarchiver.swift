#!/usr/bin/env swift

import Foundation
import Darwin // Required for signal handling on macOS

// Structure to manage command line options
struct CommandLineOptions {
    var notouching: Bool = false
    var directoryPath: String?
}

// Function to display help
func showHelp() {
    print("""
    Usage: fcarchiver [OPTIONS] <directory>

    Converts a specified directory into a Final Cut Pro archive by generating a plist file (FCArchMetadata.plist) and adjusting the creation dates of media files based on metadata.

    Options:
      --help        Show this help message and exit
      --notouching  Disable date extraction and modification of creation dates

    Dependencies:
      - uuidgen: To generate unique identifiers for files and the directory.
      - mediainfo: To extract creation dates from media files.

    """)
}

// Function to read command line options
func parseCommandLineArguments() -> CommandLineOptions {
    var options = CommandLineOptions()
    
    var iterator = CommandLine.arguments.dropFirst().makeIterator()
    while let arg = iterator.next() {
        switch arg {
        case "--help":
            showHelp()
            exit(0)
        case "--notouching":
            options.notouching = true
        default:
            options.directoryPath = arg
        }
    }
    
    return options
}

// Function to run a shell command
func runShellCommand(_ command: String, arguments: [String]) -> String? {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: command)
    process.arguments = arguments

    let pipe = Pipe()
    process.standardOutput = pipe

    do {
        try process.run()
        process.waitUntilExit()
    } catch {
        print("Error: Failed to run command \(command)")
        return nil
    }

    let data = pipe.fileHandleForReading.readDataToEndOfFile()
    return String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
}

// Function to get creation date using mediainfo
func getCreationDateFromMediaInfo(filePath: String) -> String {
    let attributesToCheck = ["Recorded_Date", "Start_Time", "Encoded_Date"]
    
    for attribute in attributesToCheck {
        if let output = runShellCommand("/opt/homebrew/bin/mediainfo", arguments: ["--Inform=General;%\(attribute)%", filePath]),
           !output.isEmpty {
            return output.replacingOccurrences(of: ":", with: "_")
        }
    }
    
    print("Warning: Could not retrieve date for \(filePath); defaulting to 1970-01-01_00_00_00.")
    return "1970-01-01_00_00_00"
}

// Function to generate a UUID
func generateUUID() -> String {
    return UUID().uuidString
}

// Function to parse a date string and return as Date type
func parseDate(_ dateString: String) -> Date? {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy_MM_dd_HH_mm_ss"
    return formatter.date(from: dateString)
}

// Function to find the oldest date
func findOldestDate(dates: [String]) -> String {
    let parsedDates = dates.compactMap { parseDate($0) }
    if let oldest = parsedDates.min() {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return formatter.string(from: oldest).replacingOccurrences(of: " ", with: "_")
    }
    return "1970-01-01_00_00_00"
}

// Function to prompt user for directory selection
func promptForDirectoryChoice() -> [String]? {
    print("""
    Please choose which directories to include in the plist:
    1. Root directory only
    2. Original Media only
    3. Original Media + Transcoded Media + Optimized Media
    """)
    
    print("Enter your choice (1/2/3): ", terminator: "")
    guard let choice = readLine(), let option = Int(choice) else {
        return nil
    }
    
    switch option {
    case 1:
        return [""]
    case 2:
        return ["Original Media"]
    case 3:
        return ["Original Media", "Transcoded Media", "Optimized Media"]
    default:
        return nil
    }
}

// Main function
func main() {
    let options = parseCommandLineArguments()
    guard let directoryPath = options.directoryPath else {
        print("Error: No directory specified.")
        showHelp()
        exit(1)
    }

    let fileManager = FileManager.default
    guard let selectedDirectories = promptForDirectoryChoice() else {
        print("Invalid choice. Exiting.")
        exit(1)
    }

    let mediaExtensions = ["mov", "mp4", "avi", "m4v", "mxf", "mts", "m2t", "wav", "mp3", "aac", "m4a", "aiff", "aif", "jpeg", "jpg", "png", "tiff", "bmp", "gif", "tif"]
    var filesToProcess = [(path: String, date: String)]()

    // Search for media files in the chosen directories
    for subdirectory in selectedDirectories {
        let searchPath = (directoryPath as NSString).appendingPathComponent(subdirectory)
        
        guard let files = try? fileManager.contentsOfDirectory(atPath: searchPath) else {
            print("Warning: Cannot read directory \(searchPath)")
            continue
        }
        
        for file in files {
            let filePath = (searchPath as NSString).appendingPathComponent(file)
            let fileExtension = (file as NSString).pathExtension.lowercased()

            if mediaExtensions.contains(fileExtension) {
                let date = getCreationDateFromMediaInfo(filePath: filePath)
                filesToProcess.append((filePath, date))
                print("File added: \(filePath) with date \(date)")
            }
        }
    }

    // Display files to be added and their dates
    print("\nFiles to be added to plist:")
    for file in filesToProcess {
        print("File: \(file.path), Date: \(file.date)")
    }

    // Calculate the oldest date among all files for the archive date
    let oldestDate = findOldestDate(dates: filesToProcess.map { $0.date })

    // Ask for confirmation before creating the plist file
    print("\nProceed with generating the plist file? (y/n): ", terminator: "")
    guard let confirmation = readLine(), confirmation.lowercased() == "y" else {
        print("Operation cancelled.")
        exit(0)
    }

    // Generate the plist file at the root of the main directory
    let plistFile = (directoryPath as NSString).appendingPathComponent("FCArchMetadata.plist")
    let plistData: [String: Any] = [
        "UUID": generateUUID(),
        "archiveDate": oldestDate,
        "archiveVersion": 1.0,
        "clipIDs": filesToProcess.map { _ in ["clipID": generateUUID()] },
        "deviceName": "Default Device", // Ask user for specific input if needed
        "isCapture": true
    ]

    // Save the plist file
    (plistData as NSDictionary).write(toFile: plistFile, atomically: true)
    print("Plist file created: \(plistFile)")
    }

main()