#!/bin/bash

# Color Definitions
COLOR_RESET='\033[0m'
COLOR_BLUE='\033[1;34m'
COLOR_GREEN='\033[1;32m'
COLOR_YELLOW='\033[1;33m'
COLOR_RED='\033[1;31m'
COLOR_CYAN='\033[1;36m'

# Check if mediainfo and ffmpeg are available
if ! which mediainfo > /dev/null; then
  echo -e "${COLOR_RED}mediainfo is required but not installed. Please install it using 'brew install mediainfo'.${COLOR_RESET}"
  exit 1
fi

if ! which ffmpeg > /dev/null; then
  echo -e "${COLOR_RED}ffmpeg is required but not installed. Please install it using 'brew install ffmpeg'.${COLOR_RESET}"
  exit 1
fi

# Extract date from filename
extract_date_from_filename() {
  local file="$1"
  local base_name; base_name=$(basename "$file" | sed -e 's/\.[^.]*$//') # Remove extension
  local digits; digits=$(echo "$base_name" | grep -o '[0-9]*')
  local creation_date
  if [[ ${#digits} -ge 14 ]]; then
    creation_date=${digits: -14}
    printf "%s-%s-%sT%s:%s:%sZ\n" \
      "${creation_date:0:4}" "${creation_date:4:2}" "${creation_date:6:2}" \
      "${creation_date:8:2}" "${creation_date:10:2}" "${creation_date:12:2}"
  else
    printf ""
  fi
}

# Choose the directory containing the media files
media_dir="$1"

if [[ -z "$media_dir" ]]; then
  echo -e "${COLOR_RED}Please provide a directory containing the media files.${COLOR_RESET}"
  exit 1
fi

# Case-insensitive search for .dv, .avi, .m2t files
shopt -s nocaseglob
files=("$media_dir"/*.{dv,avi,m2t,mov})

# Remove trailing slash from the media directory (if present)
media_dir=$(echo "$media_dir" | sed 's:/*$::')

# Only include valid files (exclude any directories or invalid files), no subdirectories
files=($(find "$media_dir" -maxdepth 1 -type f \( -iname "*.dv" -o -iname "*.avi" -o -iname "*.m2t" -o -iname "*.mov" \)))

if [[ ${#files[@]} -eq 0 ]]; then
  echo -e "${COLOR_RED}No media files found in the specified directory.${COLOR_RESET}"
  exit 1
fi

# Data array
declare -a media_info_table
index=0

echo -e "${COLOR_BLUE}Analyzing media files, please wait...${COLOR_RESET}"

# Analyze each media file with mediainfo
total_files=${#files[@]}
for file in "${files[@]}"; do
  # Display file processing progress
  echo -ne "${COLOR_CYAN}Processing file $((index + 1)) of $total_files...${COLOR_RESET}\r"
  
  # Retrieve information
  creation_date=$(mediainfo --Inform="General;%Recorded_Date%" "$file" | sed 's/ /T/')
  
  # Fallback if Recorded_Date is empty
  if [[ -z "$creation_date" ]]; then
    creation_date=$(mediainfo --Inform="General;%Encoded_Date%" "$file" | sed 's/ /T/')
  fi
  
  # Clean up timezone info if present
  creation_date=$(echo "$creation_date" | sed 's/ UTC//; s/ +.*//')
  
  # Convert creation date to ISO 8601 format for each file
  creation_date_iso=$(date -j -f "%Y-%m-%dT%H:%M:%S" "$creation_date" "+%Y-%m-%dT%H:%M:%SZ")

  format=$(mediainfo "$file" | grep -i "Commercial name" | head -n 1 | sed 's/.*Commercial name *: //')
  scan_type=$(mediainfo --Inform="Video;%ScanType%" "$file")
  scan_order=$(mediainfo --Inform="Video;%ScanOrder%" "$file")

  # Convert scan_order to lowercase
  scan_order_lower=$(echo "$scan_order" | tr '[:upper:]' '[:lower:]')

  # Determine frame mode based on scan type
  if [[ "$scan_type" == "Interlaced" ]]; then
    frame_mode="send_field"
    parity_filter="parity=$scan_order_lower"  # e.g., parity=bff or parity=tff
  else
    frame_mode="send_frame"
    parity_filter=""
  fi

  # Format output filename as YYYY-MM-DD_hhmmss
  creation_date_only="${creation_date_iso:0:10}"    # YYYY-MM-DD
  hour="${creation_date_iso:11:2}"                   # hh
  minute="${creation_date_iso:14:2}"                 # mm
  second="${creation_date_iso:17:2}"                 # ss
  
  output_file_name="${creation_date_only}_${hour}${minute}${second}"  # Corrected format: YYYY-MM-DD_hhmmss
  output_file="${output_file_name}.mov"

  # Add details to the media info table
  media_info_table+=("$(printf "${COLOR_GREEN}%-30s${COLOR_RESET} ${COLOR_YELLOW}%-20s${COLOR_RESET} ${COLOR_BLUE}%-10s${COLOR_RESET} ${COLOR_BLUE}%-10s${COLOR_RESET} ${COLOR_BLUE}%-10s${COLOR_RESET} ${COLOR_GREEN}%-10s${COLOR_RESET}" \
  "$file" "$creation_date_iso" "$format" "$scan_type" "$scan_order" "$output_file")")

  ((index++))
done
echo -e "${COLOR_RESET}"

# Display media information
echo -e "${COLOR_BLUE}Analysis complete. Below is the table of media details:${COLOR_RESET}"
echo -e "${COLOR_BLUE}File                           Creation Date        Format          Scan Type       Scan Order      Transcoded Output${COLOR_RESET}"
for row in "${media_info_table[@]}"; do
  echo -e "$row"
done

# Ask user which format to use for transcoding
read -p "Do you want to transcode (HEVC) or remux (ProRes) ? [hevc/prores/both] (default: prores): " transcoding_option
transcoding_option=${transcoding_option:-prores}

# Confirm transcoding
read -p "Proceed with transcoding/remuxing? [Y/n]: " confirm
confirm=${confirm:-Y}

if [[ "$confirm" =~ ^[Yy]$ ]]; then
  echo -e "${COLOR_GREEN}Starting transcoding/remuxing process...${COLOR_RESET}"

  # Create necessary directories
  mkdir -p "$media_dir/Original Media"
  mkdir -p "$media_dir/Transcoded Media"
  mkdir -p "$media_dir/Optimized Media"

  for file in "${files[@]}"; do
    # Calculate the creation_date_iso for each file individually within the transcoding loop
    creation_date=$(mediainfo --Inform="General;%Recorded_Date%" "$file" | sed 's/ /T/')
    if [[ -z "$creation_date" ]]; then
      creation_date=$(mediainfo --Inform="General;%Encoded_Date%" "$file" | sed 's/ /T/')
    fi
    creation_date=$(echo "$creation_date" | sed 's/ UTC//; s/ +.*//')
    creation_date_iso=$(date -j -f "%Y-%m-%dT%H:%M:%S" "$creation_date" "+%Y-%m-%dT%H:%M:%SZ")

    # Format output filename again as YYYY-MM-DD_hhmmss for each file
    creation_date_only="${creation_date_iso:0:10}"    # YYYY-MM-DD
    hour="${creation_date_iso:11:2}"                   # hh
    minute="${creation_date_iso:14:2}"                 # mm
    second="${creation_date_iso:17:2}"                 # ss
  
    output_file_name="${creation_date_only}_${hour}${minute}${second}"  # Corrected format: YYYY-MM-DD_hhmmss
    output_file="${output_file_name}.mov"

    format=$(mediainfo "$file" | grep -i "Commercial name" | head -n 1 | sed 's/.*Commercial name *: //')

    if [[ "$format" == *"HDV"* ]]; then
      bitrate="26M"
    else
      bitrate="13M"
    fi

    # Transcode to HEVC if selected
    if [[ "$transcoding_option" == "hevc" || "$transcoding_option" == "both" ]]; then
      output_file_with_extension="${output_file}"
      echo -ne "${COLOR_CYAN}Transcoding HEVC: $output_file_with_extension...${COLOR_RESET}\r"
      ffmpeg -hide_banner -loglevel error -y -i "$file" \
        -vf "bwdif=mode=$frame_mode${parity_filter:+:$parity_filter}" \
        -c:v hevc_videotoolbox -b:v "$bitrate" -tag:v hvc1 -pix_fmt yuv420p \
        -c:a aac -b:a 256k -ar 48000 -ac 2 -movflags +faststart -write_tmcd 0 \
        -metadata creation_time="$creation_date_iso" \
        "$media_dir/Transcoded Media/$output_file_with_extension"
    fi

    # Remux to ProRes if selected
    if [[ "$transcoding_option" == "prores" || "$transcoding_option" == "both" ]]; then
      output_file_with_extension="${output_file}"
      echo -ne "${COLOR_CYAN}Transcoding ProRes: $output_file_with_extension...${COLOR_RESET}\r"
      ffmpeg -copy_unknown -hide_banner -loglevel error -y -i "$file" \
        -r 25 -c copy -map 0 \
        -movflags +faststart \
        -metadata creation_time="$creation_date_iso" \
        "$media_dir/Optimized Media/$output_file_with_extension"
    fi
  done

  echo -e "${COLOR_GREEN}Transcoding/Remuxing complete.${COLOR_RESET}"
fi