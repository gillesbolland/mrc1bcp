#!/usr/bin/env swift

import Foundation
import Darwin // Required for signal handling on macOS

// ANSI color codes
let reset = "\u{001B}[0m"
let red = "\u{001B}[31m"
let green = "\u{001B}[32m"
let yellow = "\u{001B}[33m"
let blue = "\u{001B}[34m"

// Date formatter for parsing timestamps
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "yyyy-MM-dd HH_mm_ss"

// Utility function to prompt the user with a default "Yes" option
func promptYesOrNo(message: String) -> Bool {
    print("\(yellow)\(message) [Y/n]: \(reset)", terminator: "")
    if let response = readLine(), response.lowercased() == "n" {
        return false
    }
    return true
}

// Function to print usage instructions
func printUsage() {
    print("""
    Usage: command [sourceVol] [destinationDir]

    Parameters:
    - sourceVol: The source volume path (default: "/Volumes/VIDEO/").
    - destinationDir: The destination directory (default: current directory).

    Options:
    --help: Display this help message.
    """)
}

// Handle command-line arguments
let args = CommandLine.arguments

if args.count == 1 || args.contains("--help") {
    printUsage()
    exit(0)
}

let sourceVol = args.count > 1 ? args[1] : "/Volumes/VIDEO/"
let sourceDir = sourceVol + "VIDEO/HVR"
let destinationDir = args.count > 2 ? args[2] : FileManager.default.currentDirectoryPath
let mediaDir = destinationDir

// Check if source directory exists
guard FileManager.default.fileExists(atPath: sourceDir) else {
    print("\(red)The path \(sourceDir) does not exist. Please connect the Sony HVR-MRC1 memory card.\(reset)")
    exit(1)
}

// Helper function to sort files by numeric order
func sortClipFiles(_ clipFiles: [String]) -> [String] {
    return clipFiles.sorted { $0.localizedStandardCompare($1) == .orderedAscending }
}

// Helper function to sort files by timestamp
func sortByTimestamp(_ files: [URL]) -> [URL] {
    return files.sorted {
        let timestamp1 = $0.deletingPathExtension().lastPathComponent.split(separator: "_").dropFirst(2).joined(separator: "_")
        let timestamp2 = $1.deletingPathExtension().lastPathComponent.split(separator: "_").dropFirst(2).joined(separator: "_")
        return timestamp1 < timestamp2
    }
}

// List all files in a directory recursively
func listFiles(in directory: URL) -> [URL] {
    let fileManager = FileManager.default
    guard let enumerator = fileManager.enumerator(at: directory, includingPropertiesForKeys: nil) else {
        return []
    }
    return enumerator.compactMap { $0 as? URL }.filter { !$0.hasDirectoryPath }
}

// Gather existing files in the destination
let existingFiles = Set(listFiles(in: URL(fileURLWithPath: mediaDir)).map { $0.lastPathComponent.lowercased() })

// Collect and organize files by clip ID
var clipFiles = [String: [(file: URL, isNew: Bool)]]()
for file in try! FileManager.default.contentsOfDirectory(atPath: sourceDir).map({ URL(fileURLWithPath: sourceDir).appendingPathComponent($0) }) {
    let filename = file.lastPathComponent.lowercased()
    
    // Check for valid file extensions
    guard filename.hasSuffix(".m2t") || filename.hasSuffix(".dv") || filename.hasSuffix(".avi") else { continue }
    
    // Determine if the file is new or already exists
    let isNew = !existingFiles.contains(filename)
    
    let components = filename.split(separator: "_")
    guard components.count >= 4 else {
        print("\(red)Skipping file with unexpected format: \(filename)\(reset)")
        continue
    }
    
    let clipID = String(components[1])
    clipFiles[clipID, default: []].append((file: file, isNew: isNew))
}

// Sort and display files
let sortedClipFiles = clipFiles.sorted(by: { $0.key < $1.key })
var multiSegmentClips = ""
var nonFragmentedClips = ""

for (clipID, files) in sortedClipFiles {
    // Start each clip header without color
    var annotatedFiles = "\(reset)- Clip \(clipID):\n"
    
    annotatedFiles += files.map {
        $0.isNew
            ? "\(green)new: \($0.file.lastPathComponent)\(reset)"
            : "\(blue)\($0.file.lastPathComponent)\(reset)"
    }.joined(separator: "\n")
    
    if files.count > 1 {
        multiSegmentClips += "\(annotatedFiles)\n"
    } else {
        nonFragmentedClips += "\(annotatedFiles)\n"
    }
}

// Display results
if !multiSegmentClips.isEmpty {
    print("\(blue)Detected clips with multiple segments:\n\(reset)\(multiSegmentClips)")
} else {
    print("\(blue)No clips with multiple segments detected.\(reset)")
}

if !nonFragmentedClips.isEmpty {
    print("\(blue)Detected non-fragmented clips:\n\(reset)\(nonFragmentedClips)")
} else {
    print("\(blue)No non-fragmented clips detected.\(reset)")
}

// Confirm copy and merge operation
if !promptYesOrNo(message: "Do you want to proceed with copying and merging split clips?") {
    print("\(red)Aborted.\(reset)")
    exit(1)
}

// Copy and merge only new files
for (clipID, files) in sortedClipFiles {
    let newFiles = files.filter { $0.isNew }.map { $0.file }
    let sortedFiles = sortByTimestamp(newFiles)
    
    if sortedFiles.count > 1 {
        let mergedFileURL = URL(fileURLWithPath: mediaDir).appendingPathComponent(sortedFiles[0].lastPathComponent)
        FileManager.default.createFile(atPath: mergedFileURL.path, contents: nil, attributes: nil)
        
        if let fileHandle = try? FileHandle(forWritingTo: mergedFileURL) {
            defer { fileHandle.closeFile() }
            for segment in sortedFiles {
                if let segmentData = try? Data(contentsOf: segment) {
                    fileHandle.write(segmentData)
                } else {
                    print("\(red)Failed to read segment \(segment.lastPathComponent)\(reset)")
                }
            }
            print("\(green)Merged files for clip \(clipID) into \(mergedFileURL.lastPathComponent).\(reset)")
        } else {
            print("\(red)Failed to open \(mergedFileURL.path) for writing.\(reset)")
        }
    } else if sortedFiles.count == 1 {
        do {
            let destinationURL = URL(fileURLWithPath: mediaDir).appendingPathComponent(sortedFiles[0].lastPathComponent)
            try FileManager.default.copyItem(at: sortedFiles[0], to: destinationURL)
            print("\(green)File \(sortedFiles[0].lastPathComponent) copied to \(mediaDir).\(reset)")
        } catch {
            print("\(red)Error copying file: \(error)\(reset)")
        }
    }
}

print("\(green)File operations completed.\(reset)")

// Prompt to eject the volume after completion
if promptYesOrNo(message: "Do you want to eject the volume \(sourceDir)?") {
    let task = Process()
    task.executableURL = URL(fileURLWithPath: "/usr/sbin/diskutil")
    task.arguments = ["eject", sourceVol]
    
    do {
        try task.run()
        task.waitUntilExit()
        if task.terminationStatus == 0 {
            print("\(green)Volume \(sourceDir) successfully ejected.\(reset)")
        } else {
            print("\(red)Failed to eject volume \(sourceDir).\(reset)")
        }
    } catch {
        print("\(red)Error ejecting volume: \(error)\(reset)")
    }
}