#!/usr/bin/env swift

import Foundation
import Darwin // Required for signal handling on macOS.

// Settings
let mediainfoPath = "/opt/homebrew/bin/mediainfo"
let debugMode = false // Set to true to enable debug messages

// Utility functions for colored output
func coloredText(_ text: String, color: String) -> String {
    return "\(color)\(text)\u{001B}[0m"
}

let redColor = "\u{001B}[31m"
let greenColor = "\u{001B}[32m"
let yellowColor = "\u{001B}[33m"
let blueColor = "\u{001B}[34m"

// Debug print
func debugPrint(_ message: String) {
    if debugMode {
        print(coloredText("[DEBUG] \(message)", color: yellowColor))
    }
}

// Function to display usage information
func displayHelp(detailed: Bool) {
    let briefHelp = """
    Usage: timestamp [extension]
    """
    let detailedHelp = """
    Usage: timestamp [extension]

    Description:
      This script processes media files in the current directory, extracts their recorded date using the 'mediainfo' tool, renames the files based on the extracted date, and updates their file modification date.

    Arguments:
      [extension]     The file extension to process (e.g., mov, mp4). Default is 'mov'.

    Options:
      --help          Show this detailed help message.

    Requirements:
      - The 'mediainfo' tool must be installed and its path correctly configured in the script.
      - Ensure appropriate permissions to read, rename, and modify files.

    Notes:
      - The script operates only on files with the specified extension in the current directory.
      - The new file names follow the format: yyyy-MM-dd_HHmmss.extension.
      - Debug messages can be enabled by setting 'debugMode' to true in the script.

    Example:
      ./script.swift mp4
      Processes all '.mp4' files in the current directory.
    """
    print(detailed ? detailedHelp : briefHelp)
}

// Main script logic
if CommandLine.arguments.contains("--help") || CommandLine.arguments.count == 1 {
    displayHelp(detailed: CommandLine.arguments.contains("--help"))
    exit(0)
}

// Function to extract date from mediainfo output
func extractDate(from filePath: String) -> String? {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: mediainfoPath)
    process.arguments = ["--Inform=General;%Recorded_Date%\\n%Encoded_Date%", filePath]

    let pipe = Pipe()
    process.standardOutput = pipe

    do {
        try process.run()
    } catch {
        print(coloredText("Error: Unable to execute mediainfo.", color: redColor))
        return nil
    }

    let data = pipe.fileHandleForReading.readDataToEndOfFile()
    guard let output = String(data: data, encoding: .utf8) else { return nil }
    
    debugPrint("Raw mediainfo output for \(filePath): \(output)")

    // Extract dates from "Recorded Date" and "Encoded Date"
    let lines = output.components(separatedBy: "\n")
    for line in lines {
        let trimmedLine = line.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedLine.count > 0 {
            debugPrint("Found valid date: \(trimmedLine)")
            return trimmedLine
        }
    }

    return nil
}

// Function to rename file and update creation date
func renameAndTouchFile(at oldPath: String, to newPath: String, with date: String) {
    let renameProcess = Process()
    renameProcess.executableURL = URL(fileURLWithPath: "/bin/mv")
    renameProcess.arguments = [oldPath, newPath]

    do {
        try renameProcess.run()
        renameProcess.waitUntilExit()
    } catch {
        print(coloredText("Error: Unable to rename file \(oldPath).", color: redColor))
    }

    let touchProcess = Process()
    touchProcess.executableURL = URL(fileURLWithPath: "/usr/bin/touch")
    touchProcess.arguments = ["-t", date, newPath]

    do {
        try touchProcess.run()
        touchProcess.waitUntilExit()
    } catch {
        print(coloredText("Error: Unable to update file date for \(newPath).", color: redColor))
    }
}

// Format date for touch and rename
func formatDateForRenameAndTouch(_ dateStr: String) -> (String, String)? {
    let formatter = DateFormatter()
    let trimmedDateStr = dateStr.replacingOccurrences(of: ".000", with: "")
    
    // Define possible date formats, omitting timezone offsets to enforce local time parsing
    let possibleFormats = [
        "yyyy-MM-dd HH:mm:ss", // Without timezone, assumes local time
        "yyyy-MM-dd HH:mm:ss 'UTC'", // Removes UTC suffix, enforces local time parsing
    ]
    
    // Force the formatter to interpret dates in local time
    formatter.timeZone = .current
    
    var date: Date? = nil
    for format in possibleFormats {
        formatter.dateFormat = format
        if let parsedDate = formatter.date(from: trimmedDateStr) {
            date = parsedDate
            break
        }
    }
    
    guard let validDate = date else {
        print(coloredText("Warning: Invalid date format for date: \(trimmedDateStr)", color: redColor))
        return nil
    }
    
    // Formatting new name and touch date without offset for local time
    let newNameFormatter = DateFormatter()
    newNameFormatter.dateFormat = "yyyy-MM-dd_HHmmss" // Naming format
    let touchDateFormatter = DateFormatter()
    touchDateFormatter.dateFormat = "yyyyMMddHHmm"     // Format required by 'touch' command
    
    let newName = newNameFormatter.string(from: validDate)
    let touchDate = touchDateFormatter.string(from: validDate)
    return (newName, touchDate)
}

// Main script logic
let fileExtension = CommandLine.arguments.count > 1 ? CommandLine.arguments[1].lowercased() : "mov"
let fileManager = FileManager.default
let currentPath = fileManager.currentDirectoryPath

do {
    let files = try fileManager.contentsOfDirectory(atPath: currentPath)
    var fileInfo: [(originalName: String, recordedDate: String, newName: String, touchDate: String)] = []

    for file in files where file.lowercased().hasSuffix(".\(fileExtension)") {
        debugPrint("Extracting date for file: \(file)")
        if let dateStr = extractDate(from: file), let (newName, touchDate) = formatDateForRenameAndTouch(dateStr) {
            let newFileName = "\(newName).\(fileExtension)"
            fileInfo.append((file, dateStr, newFileName, touchDate))
            debugPrint("Formatted newName: \(newName), touchDate: \(touchDate)")
        } else {
            print(coloredText("Unable to retrieve valid date for file: \(file)", color: redColor))
        }
    }

    if fileInfo.isEmpty {
        print(coloredText("No valid dates found in files.", color: redColor))
        exit(0)
    }

    // Display summary and confirm
    print(coloredText("\nFiles to be renamed:", color: blueColor))
    print("Original Name        | Recorded Date        | New Name               | Touch Date")
    print("---------------------|----------------------|-------------------------|------------------")
    for info in fileInfo {
        print("\(info.originalName.padding(toLength: 20, withPad: " ", startingAt: 0)) | \(info.recordedDate.padding(toLength: 20, withPad: " ", startingAt: 0)) | \(info.newName.padding(toLength: 25, withPad: " ", startingAt: 0)) | \(info.touchDate)")
    }

    print(coloredText("\nProceed with renaming and updating file dates? (Y/n)", color: greenColor))
    let response = readLine()?.lowercased() ?? "y"
    if response.isEmpty || response == "y" {
        for info in fileInfo {
            renameAndTouchFile(at: info.originalName, to: info.newName, with: info.touchDate)
        }
        print(coloredText("Operation completed.", color: greenColor))
    } else {
        print(coloredText("Operation cancelled.", color: redColor))
    }
} catch {
    print(coloredText("Error: Unable to read directory contents.", color: redColor))
}